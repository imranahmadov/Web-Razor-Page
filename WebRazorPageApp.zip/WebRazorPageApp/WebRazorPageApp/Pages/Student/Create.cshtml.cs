﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WebRazorPageApp.DAL;
using WebRazorPageApp.Model;

namespace WebRazorPageApp
{
    public class CreateModel : PageModel
    {
        private readonly AppDbContext _db;
        public CreateModel(AppDbContext db)
        {
            _db = db;
        }
        [BindProperty]
        public Student Student { get; set; }
        public void OnGet()
        {

        }

        public async Task<IActionResult> OnPost()
        {
            if(!ModelState.IsValid)
                return Page();
            await _db.Students.AddAsync(Student);
            await _db.SaveChangesAsync();
            
            return RedirectToPage("/Student/Index");
        }
    }
}