﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebRazorPageApp.Migrations
{
    public partial class addDataStudentTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "Name", "Surname" },
                values: new object[] { 1, "Mubariz", "Memmedzade" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "Name", "Surname" },
                values: new object[] { 2, "Javid", "Esedullayev" });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "Name", "Surname" },
                values: new object[] { 3, "Selcan", "Ehmedova" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Students",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
