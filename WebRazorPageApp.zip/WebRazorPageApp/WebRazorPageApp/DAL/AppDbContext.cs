﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebRazorPageApp.Model;

namespace WebRazorPageApp.DAL
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options):base(options)
        {
        }

        public DbSet<Student> Students { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Student>().HasData(
                new Student { Id = 1,Name="Mubariz",Surname="Memmedzade" },
                new Student { Id = 2, Name = "Javid", Surname = "Esedullayev" },
                new Student { Id = 3, Name = "Selcan", Surname = "Ehmedova" }
            );
        }
    }
}
